This code creates the individual tables.  An empty database needs to be created first --
it needs a container to be imported into.  This is not the same as a sql dump file.  
There are 2 files - one with primary keys and one without (NoRefs).  I've included the datbase
diagrams.